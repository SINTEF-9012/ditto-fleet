#!/bin/bash

# Starting timestamp
start_time=$(date +%s)

# Infinite loop
while true
do
  # Current timestamp
  current_time=$(date +%s)
  
  # Calculate the difference in seconds
  elapsed=$((current_time - start_time))
  
  # Print the message with elapsed time
  echo "Hello, I've been running for $elapsed seconds."
  
  # Sleep for 10 seconds
  sleep 10
done
